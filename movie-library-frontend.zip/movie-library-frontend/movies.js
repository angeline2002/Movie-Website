document.getElementById('search-button').addEventListener('click', async () => {
    const query = document.getElementById('search-query').value;
    try {
      const res = await fetch(`http://localhost:5000/api/movies/search?query=${query}`);
      const movies = await res.json();
      const searchResults = document.getElementById('search-results');
      searchResults.innerHTML = '';
      movies.forEach(movie => {
        const div = document.createElement('div');
        div.innerText = `${movie.Title} (${movie.Year})`;
        searchResults.appendChild(div);
      });
    } catch (err) {
      alert('Error: ' + err.message);
    }
  });
  