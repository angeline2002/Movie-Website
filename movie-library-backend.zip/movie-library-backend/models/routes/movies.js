const express = require('express');
const axios = require('axios');
const MovieList = require('../models/MovieList');
const jwt = require('jsonwebtoken');

const router = express.Router();

// Middleware to authenticate token
const auth = (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    res.status(401).send('Unauthorized');
  }
};

// Search Movies (using OMDB API)
router.get('/search', async (req, res) => {
  const { query } = req.query;
  try {
    const response = await axios.get(`http://www.omdbapi.com/?apikey=${process.env.OMDB_API_KEY}&s=${query}`);
    res.json(response.data.Search);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Create Movie List
router.post('/lists', auth, async (req, res) => {
  const { name, isPublic, movies } = req.body;
  const list = new MovieList({ userId: req.userId, name, isPublic, movies });
  try {
    await list.save();
    res.status(201).send('List created');
  } catch (err) {
    res.status(500).send(err.message);
  }
});

// Get User's Lists
router.get('/lists', auth, async (req, res) => {
  try {
    const lists = await MovieList.find({ userId: req.userId });
    res.json(lists);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

module.exports = router;
